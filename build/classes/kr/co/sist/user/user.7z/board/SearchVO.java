package kr.co.sist.user.board;

/**
 * 현재페이지, 시작번호, 끝 번호, 검색컬럼, 검색값, 검색URL
 */
public class SearchVO {

}
