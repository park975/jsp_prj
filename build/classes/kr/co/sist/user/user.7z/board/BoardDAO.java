package kr.co.sist.user.board;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import kr.co.sist.dao.DbConnection;

/**
 *  게시판의 리스트, 상세조회, 추가, 삭제, 변경 업무
 */
public class BoardDAO {
	
	private static BoardDAO bDAO;
	
	private BoardDAO() {
	}
	
	public static BoardDAO getInstance() {
		if(bDAO == null) {
			bDAO=new BoardDAO();
		}//end if
		return bDAO;
	}//getInstance
	
	
	/**
	 * 총 게시물의 수 검색
	 * @param sVO
	 * @return 게시물의 수
	 * @throws SQLException
	 */
	public int selectTotalCount( SearchVO sVO)throws SQLException{
		int totalCount=0;
		
		Connection con=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		
		DbConnection dbCon=DbConnection.getInstance();
		//1.JNDI 사용객체 생성
		//2.DBCP에서 DataSource 얻기
		
		try {
		//3.Connection얻기
			con=dbCon.getConn();
		//4.쿼리문생성객체 얻기
			StringBuilder selectCount=new StringBuilder();
			selectCount
			.append("select count(num) cnt from board ");
			
			pstmt=con.prepareStatement(selectCount.toString());
		//5.바인드 변수에 값 설정
			
		//6.쿼리문 수행후 결과 얻기
			rs=pstmt.executeQuery();
			if(rs.next()) {
				totalCount=rs.getInt("cnt");
			}//end if
		}finally {
		//7.연결 끊기
			dbCon.dbClose(rs, pstmt, con);
		}//end finally
		return totalCount;
	}//selectTotalCount
	
	
}//class
